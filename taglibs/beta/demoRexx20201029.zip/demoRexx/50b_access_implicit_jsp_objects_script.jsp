<%--
    ------------------------ Apache Version 2.0 license -------------------------
       Copyright 2020 Rony G. Flatscher

       Licensed under the Apache License, Version 2.0 (the "License");
       you may not use this file except in compliance with the License.
       You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing, software
       distributed under the License is distributed on an "AS IS" BASIS,
       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       See the License for the specific language governing permissions and
       limitations under the License.
    -----------------------------------------------------------------------------
    ------------------------ Common Public License 1.0 --------------------------
       Copyright 2020 Rony G. Flatscher

       This program and the accompanying materials are made available under the
       terms of the Common Public License v1.0 which accompanies this distribution.

       It may also be viewed at: http://www.opensource.org/licenses/cpl1.0.php
    -----------------------------------------------------------------------------
--%>

<%@ page session="false" pageEncoding="UTF-8" contentType="text/html; charset=UTF-8" %>
<%@ taglib uri="/WEB-INF/script-jsr223.tld" prefix="s" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<style>
body { background-color: ivory; }
table, th, td {
  border: 1px solid blue;
  border-collapse: collapse;
  padding: 5px;
  }
</style>
<title>Demonstrate Howto Get At Supplied Data Via Script (JSR223) (title)</title>
</head>
<body>

<div style="float: left; padding: 10px;">
<img src="images/bsf4oorexx_064.png" alt="" />
</div>
<h1>Demonstrate Howto Get At Supplied Data Via Script (JSR223)  </h1>

<p>The taglib library supplies the implicit objects &quot;request&quot;,
&quot;response&quot; and &quot;out&quot; as arguments on each invocation.
RexxScript in addition supplies a slot argument (a Rexx directory object).</p>

<s:script type="rexx">
use arg request, response, out, slotDir
scriptContext=slotDir~scriptContext -- fetch script context from slot argument

    -- save array with variable names in .local
.local~var.Names=.array~of("request", "response", "out", "slotDir")
say p("These are the arguments fetched with ""use arg"":")
say "<center><table>"
do counter i varName over .var.Names
   say "<tr>" td(i) td(varName) td(value(varName)) "</tr>"
end
say "</table></center>"
say "<p/>"
say

say p("This is the content of the ""slotDir"" (always the last) argument:")
say "<center><table>"
do counter i idx over slotDir~allIndexes~sort
   say "<tr>" td(i) td(idx) td(slotDir~at(idx)) "</tr>"
end
say "</table></center>"
say "<p/>"
say

say "<p>Alternatively using the Rexx arg() built-in-function (BIF) to" -
      "get at the received arguments (there are ""arg()"" &#8702;" pp(arg()) "arguments):</p>"
say "<center><table>"
do counter i k=1 to arg()
   say "<tr>" td("arg("i")") td(arg(k)) "</tr>"
end
say "</table></center>"
say "<p/>"
say

say '<hr width="75%"/>'
   -- save array with the names of the implicit (pre-registered) objects
say p("Fetch implicit (pre-registered) objects with ""scriptContext~getAttribute()"":")
.local~obj.Names=.array~of("application","config","exception","out","page", -
    "pageContext","request","response","session","scriptTaglibTag")
say "<center><table>"
do counter i objName over .obj.Names
   say "<tr>" td(i) td(objName) td(scriptContext~getAttribute(objName)) "</tr>"
end
say "</table></center>"
say "<p/>"
say

say "<p></p>"
say '<hr width="50%"/>'

say "<center>"
say p("Show ScriptContext's and java.lang.System's stream objects:")
say "<table>"
say "<tr> <th>method/field</th>" "<th>ScriptContext (methods)</th>" "<th>java.lang.System (fields)</th>" "</tr>"
say "<tr>" td("getReader/in")       td(pp("getReader") scriptContext~getReader)      td(pp("in") .java.lang.System~in)  "</tr>"
say "<tr>" td("getWriter/out")      td(pp("getWriter") scriptContext~getWriter)      td(pp("out") .java.lang.System~out) "</tr>"
say "<tr>" td("getErrorWriter/err") td(pp("getErrorWriter") scriptContext~getErrorWriter) td(pp("err") .java.lang.System~err) "</tr>"
say "</table>"
say "<p></p>"
say '<hr width="50%"/>'


say p("Show ""scriptContext"" ""ENGINE_SCOPE"" (scope=100) and ""GLOBAL_SCOPE"" (scope=200) Bindings:")

do scope over 100, 200
    say "<table>"
    bindings=scriptContext~getBindings(scope)
    if scope=100 then say """ENGINE_SCOPE"" (scope=100) has" pp(bindings~size) "entries:"
                 else say """GLOBAL_SCOPE"" (scope=200) has" pp(bindings~size) "entries:"
    say "<p />"

    do counter i name over bindings~makearray~sort
       say "<tr>" td(i) td(name) td(escape(bindings~get(name))) "</tr>"
    end
    say "</table>"
    say '<hr width="50%"/>'
    say "<p></p>"
    say
end
say "</center>"

say "<p>Alternatively using the RexxScript annotation to fetch the implicit objects" -
    "into local Rexx variables:"
/* @get(application config exception out page pageContext) */
/* @get(request response session scriptTaglibTag) */
say "<center><table>"
do counter i objName over .obj.Names
   say "<tr>" td(i) td(objName) td(value(objName)) "</tr>"
end
say "</table></center>"
say "<p/>"
say


say '<hr width="75%"/>'
say p("Getting information on .input, .output, .error, .debuginput, .traceoutput:")
say "<center><table>"
streamNames=.array~of(".input", ".output", ".error", ".debuginput", ".traceoutput")
do name over streamNames
   o=value(name)    -- fetch value of the stream
   c=o~current      -- get current monitored object
   jo=c~javaobject
   str=td("javaobject="pp(c~javaobject)) td("prefix="pp(c~prefix))
   if name~pos("in")=0 then str=str td("endofline="pp('"'c~endofline~c2x'"x'))

   say "<tr>" td(name) td(o) td(c) str "</tr>"
end
say "</table></center>"
say "<p/>"



::requires "BSF.CLS"    -- get the Java support

::routine p
  use arg o
  if o~isA(.bsf) then o=o~objectname
  return "<p>" escape(o) "</p>"

::routine td
  use arg o
  if o~isA(.bsf) then o=o~objectname
  return "<td>" escape(o) "</td>"

::routine escape
  use arg o
  -- return o~changeStr("","")~changeStr("","")~changeStr("","")
  if \o~isA(.string) then o=o~string

  return o~changeStr("&","&amp;")~changeStr("<","&lt;")~changeStr(">","&gt;")

</s:script>


<hr width="75%" />

<p>This is just a demo program to demonstrate what arguments you get,
how you can get at the implicit (pre-registered) objects in JSR223, and how
the ooRexx streams are set up. You rarely will have a need to fetch
the implicit (pre-registered) objects, change the configuration of the
streams, therefore you may very well forget this sample, now that you know
how to do it!  &#128521;
</p>

<p>Done.<p>

</body>
</html>
