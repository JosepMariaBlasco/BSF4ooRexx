/* demonstrate how to implement a "Rexx Servlet": 2: create information about ooRexx,
   BSF4ooRexx and Java on the server side, independent of which taglib controls us */
arrivedAt=.dateTime~new
use arg request, response, out   -- servlet arguments plus 'out' to ease access

   -- determine taglib that called us, forward all received arguments to the routine <ihaa> &oha
   -- supply also last received argument which is a slotDir argument in case JSR223 invoked us
attrName="scriptTaglibTag"
res=.routines~getImplicitObject~callWith(.array~of(attrName, arg(arg()) ) )  -- get typelib information
parse var res typelib '.' tag

if typelib="BsfTaglib" then bgColor="oldlace"   -- determine the background color
                       else bgColor="ivory"

call setup                 -- define and store some useful strings in package local

title="Rexx Generated Information (".dateTime~new")"
say .resources~leadin1     -- write <head> part

   -- fetch css resource, turn explicitly into a string, change the background
   -- depending on the taglib that called this program
str = .resources~css~makeString  -- create string from array of strings
say str~changeStr("lightgoldenrodyellow",bgColor)

say tag("title", title)
say .resources~leadin2     -- close <head>, open <body> part, continue

say tag("h1",title)        -- define title of this page
say p("This was created with ooRexx at the server employing the JSP (Java Server Pages) infrastructure." -
      "In effect this particular Rexx program can be regarded as a &quot;Rexx Servlet (RSL)&quot.")
say p(".bsf4rexx~display.version:" .bsf4rexx~display.version)
say

say tag("h2","Taglib Invocation Information")
say p("This Rexx script was invoked via:")
say "<ul>"
say .tab"<li>typelib:" pp(typelib)
say .tab"<li>tag:" pp(tag)
say .tab"<li>Total number of received arguments:" pp(arg()) "<br>"
indent = .tab .tab "&nbsp;"~copies(5)
say .tab '<div style="font-family: Courier, Mono;">'
do i=1 to arg()
   say indent || "arg("i"):" pp(arg(i)) "<br>"
end
say .tab'</div>'
say "</ul>"
say

attrName="Taglib.Information"
   -- supply also last received argument which is a slotDir argument in case JSR223 invoked us
hashMap=.routines~getImplicitObject~callWith(.array~of(attrName, arg(arg()) ))
if hashMap<>.nil then   -- if implicit object exists, show its content
do
   say p("The implicit object named <em>"attrName"</em> contains the following information:")
   allIndexes=hashMap~makeArray~sortWith(.caselessComparator~new)
   arr=.array~new
   do counter i idx over allIndexes
      arr[i,1]=idx
      arr[i,2]=hashMap~get(idx)
   end
   call createTable arr, "Implicit Object &quot;"attrName"&quot; (a HashMap)"
   say
end

say tag("h2","Rexx Information")
parse version v
parse source s
say "<ul>".ct"<li>version:" pp(v) .ct"<li>source:" pp(s) .crlf"</ul>"
say

say tag("h2","BSF4ooRexx Information")
call create_BSF4ooRexx_infos
say

say tag("h2","Java System Properties")
call create_java_infos
say

say .resources~leadout  -- close document
now=.dateTime~new
-- only show as a comment at the very bottom of the generated html file
say "<!-- arrivedAt:" arrivedAt "now:" now "duration:" now-arrivedAt "-->"


::requires "BSF.CLS"    -- make sure the Java bridge is there

   ----------------------------------------------------------------------------
::routine setup      -- setup Rexx environment
   pkgLocal=.context~package~local  -- advanced Rexx: returns this package's local environment
      -- all entries can be fetched by prepending the name with a dot ("environment symbol")
   pkgLocal~crlf= "0d0a"x           -- define and save HTML CR-LF, can be fetched with .crlf
   pkgLocal~tab = "09"x             -- define and save TAB character, can be fetched with .tab
   pkgLocal~ct  = .crlf || .tab     -- define and save CR-LF-TAB, can be fetched with .ct

   ----------------------------------------------------------------------------
::routine getImplicitObject   -- get and return implicit object with the supplied attrName
   use arg attrName
   slotDir=arg(arg())      -- get last argument
   if slotDir~isA(.slot.argument) then -- if so, we got invoked by RexxScript/JSR-223
      return slotDir~scriptContext~getAttribute(attrName)
   return bsf.lookupBean(attrName)     -- we got invoked by BSF

   ----------------------------------------------------------------------------
::routine tag           -- enclose text in supplied tag, cater for tag attributes
   parse arg tag attr, text   -- parse OTAG
   return "<"tag attr">" text "</"tag">"

   ----------------------------------------------------------------------------
::routine p             -- enquote with <p> tag
   parse arg text
   return "<p>" text "</p>"

   ----------------------------------------------------------------------------
::routine create_BSF4ooRexx_infos
      -- create an array with the version information
   arr=.array~new       -- create an array
   arr[1,1]="BSF4Rexx (DLL/so)"  -- title at index 1
   arr[1,2]=BsfVersion()         -- value at index 1
   arr[2,1]="Java Rexx engine"
   arr[2,2]=bsf.wrap(bsf("version"))
   arr[3,1]="BSF.CLS"
   arr[3,2]=.bsf4rexx~version

   -- show other version information
   versions=bsf.wrap(bsf('version', 'all'))  -- get all version information
   do i=4 while versions<>""
      parse var versions clazz ver versions
      arr[i,1]=clazz
      arr[i,2]=ver
   end
   call createTable arr, "BSF4ooRexx Version Information"
   say p()

      -- create an array with the external function packages
   arr=.array~new       -- create an array
   call BsfQueryRegisteredFunctions "s."
   do i=1 to s.0
      arr~append(s.i)
   end
   call createTable arr, "BSF4ooRexx External Functions"

   ----------------------------------------------------------------------------
::routine create_Java_infos
   props=.java.lang.System~getproperties
   treeSet=.bsf~new("java.util.TreeSet", props~keySet)   -- will be sorted
   pathSep=.file~pathSeparator   -- get platform's path separator
   arr=.array~new                -- create an array
   do counter i key over treeSet~iterator
      arr[i,1]=key
      val=props~get(key)
         -- improve legibility of the values
      if key="line.separator" then
         val='"'val~c2x'"x'      -- show control chars in hex
      else if key~endsWith("path") | key~endsWith("dirs")  then
         val=val~changestr(pathSep, pathSep"<br>") -- each path on a separate line
      else
         val=val~changestr(",", ",<br>")  -- each list item on a separate line

      arr[i,2]=val
   end
   call createTable arr

   ----------------------------------------------------------------------------
::routine createTable   -- create the HTML table
   use arg arr, header=""
   dims=arr~dimension
   if dims=1 then       -- list of registered BSF functions
      say '<table style="width: 25%;" class="center">'
   else                 -- key/value pairs
      say '<table class="center">'

   if header<>"" then   -- optional header supplied?
       say .tab '<tr><th colspan="'dims+1'">' header '</th></tr>'

   do counter i k=1 to arr~items/dims
       if dims>1 then
          say .tab '<tr><td class="nr">' i '</td> <td class="key">' arr[k,1] '</td> <td class="value">' arr[k,2] '</td></tr>'
       else
          say .tab '<tr><td class="nr">' i '</td> <td class="key">' arr[k] '</td></tr>'
   end
   say "</table>"
   say


   ----------------------------------------------------------------------------
::routine escape        -- escape HTML relevant characters with their entities
   if \o~isA(.string) then o=o~string
   return o~changeStr("&","&amp;")~changeStr("<","&lt;")~changeStr(">","&gt;")

   ----------------------------------------------------------------------------
   -- create proper HTML head fragment
::resource leadin1   -- lead in HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />

::END

::resource leadin2   -- close head element, open body element fragment
</head>

<body>
<div style="float: left; padding: 10px;">
<img src="images/bsf4oorexx_064.png" alt="" />
</div>

::END

   ----------------------------------------------------------------------------
   -- close HTML document properly
::resource leadout

<p>Done.</p>

</body>
</html>
::END

   ----------------------------------------------------------------------------
   -- define CSS, note color named "lightgoldenrodyellow" will be changed by script above
::resource css

<style>

   @media screen, print {
                  /* do NOT change the color name, the Rexx script will change the color name
                     depending on how it got invoked, via the BsfTaglib (name="oldlace") or
                     the ScriptTaglib (name="ivory"); these colores are used hard-coded
                     in the other examples */
        body    { background-color:  lightgoldenrodyellow  ; /* do NOT change color name! */
                  font-family: Times, Avantgarde;
                  font-family: Arial,sans-serif;
                  font-size: 12pt; }

        h1      { color: blue;
                  text-align: center;
                  font-family: Arial,sans-serif;
                  font-size: 250%; }

        h2      { color: green;

                  border-top: 4px dotted;
                  padding-top: 20px;
                  text-align: center;
                  font-family: Arial,sans-serif;
                  font-size: 150%; }

        li      { border:  1px dashed black;
                  padding: 5px; }

        table   {   width: 80%; }

        table.center { margin-left: auto;
                       margin-right: auto; }

        table, th, td { border-collapse: collapse;
                        border: 1px dotted black;
                        padding: 3px; }

        tr      {  vertical-align: baseline;
                   font-size: 90%;}

        tr:nth-child(even) { background: lightgoldenrodyellow; }

        tr:nth-child(odd)  { background: gainsboro; }

        td.nr   {  width:     2em ;
                   font-size: 80%;
                   text-align: center; }

        td.key  {  font-family: Mono; }

        td.value { font-family: Courier, Mono;
                   width: 60%; }
   }

   @media print {
        BODY { font-size:   10pt; }

        TABLE { padding: 1px;
                font-size: 10pt; }
   }
</style>

::END


/*
    ------------------------ Apache Version 2.0 license -------------------------
       Copyright 2020 Rony G. Flatscher

       Licensed under the Apache License, Version 2.0 (the "License");
       you may not use this file except in compliance with the License.
       You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing, software
       distributed under the License is distributed on an "AS IS" BASIS,
       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       See the License for the specific language governing permissions and
       limitations under the License.
    -----------------------------------------------------------------------------
    ------------------------ Common Public License 1.0 --------------------------
       Copyright 2020 Rony G. Flatscher

       This program and the accompanying materials are made available under the
       terms of the Common Public License v1.0 which accompanies this distribution.

       It may also be viewed at: http://www.opensource.org/licenses/cpl1.0.php
    -----------------------------------------------------------------------------
*/
