/* utility that creates the invocation table information, i.e.
   it lists all available methods for each JSP supplied object and
   runs all the getter methods (get* and is* without argument), if
   not null:

      application
      config
      exception
      out               -- supplied as argument
      page
      pageContext
      request           -- supplied as argument
      response          -- supplied as argument
      session

      scriptTaglibTag


   This should allow the developer to inspect

*/

arrivedAt=.dateTime~new
use arg request, response, out   -- servlet arguments plus 'out' to ease access

   -- determine taglib that called us, forward all received arguments to the routine <ihaa> &oha
   -- supply also last received argument which is a slotDir argument in case JSR223 invoked us
objNames=.array~of("application", "config", "exception", "out", "page", "pageContext", -
                   "request", "response", "session")

say
st=.routines~getImplicitObjects~callWith(.array~of(objNames, arg(arg())) )  -- get typelib information

call setup                 -- define and store some useful strings in package local


say p(".bsf4rexx~display.version:" .bsf4rexx~display.version)

say tag("h2","Taglib Invocation Information")

sysout=.java.lang.system~out
do attrName over objNames  -- show methods of all attributes that are not null
   jobj=st[attrName]

   -- if \jobj~isNil then
   do
      say tag("h3", "Accessible Methods for" pp(attrName) )
      if jobj~isNil then
      do
         say p("No Java object available.")
      end
      else
      do
          call dumpAccessibleMethods jobj     -- dump the acessible methods
      end
      say
      .output~javaobject~flush
      sysout~flush
   end
end
say

now=.dateTime~new
-- only show as a comment at the very bottom of the generated html file
say "<!-- arrivedAt:" arrivedAt "now:" now "duration:" now-arrivedAt "-->"
say


::requires "BSF.CLS"    -- make sure the Java bridge is there

   ----------------------------------------------------------------------------
::routine setup      -- setup Rexx environment
   pkgLocal=.context~package~local  -- advanced Rexx: returns this package's local environment
      -- all entries can be fetched by prepending the name with a dot ("environment symbol")
   pkgLocal~crlf= "0d0a"x           -- define and save HTML CR-LF, can be fetched with .crlf
   pkgLocal~tab = "09"x             -- define and save TAB character, can be fetched with .tab
   pkgLocal~tab3= "090909"x         -- define and save three TAB character, can be fetched with .tab3
   pkgLocal~tab4= "09090909"x       -- define and save four TAB character, can be fetched with .tab3
   -- pkgLocal~ct  = .crlf || .tab     -- define and save CR-LF-TAB, can be fetched with .ct

   ----------------------------------------------------------------------------
::routine getImplicitObjects   -- get and return implicit object with the supplied attrName
   use arg objNames
   slotDir=arg(arg())      -- get last argument
   st=.stringTable~new
   if slotDir~isA(.slot.argument) then -- if so, we got invoked by RexxScript/JSR-223
   do
      scriptContext=slotDir~scriptContext
      do attrName over objNames -- i=1 to arg()-1
         st[attrName]=scriptContext~getAttribute(attrName)
      end
   end
   else  -- via BSF
   do attrName over objNames -- i=1 to arg()-1
      st[attrName]=bsf.lookupBean(attrName)
   end
   return st

   ----------------------------------------------------------------------------
::routine tag           -- enclose text in supplied tag, cater for tag attributes
   parse arg tag attr, text   -- parse OTAG
   return "<"tag attr">" text "</"tag">"

   ----------------------------------------------------------------------------
::routine p             -- enquote with <p> tag
   parse arg text
   return "<p>" text "</p>"


   ----------------------------------------------------------------------------
::routine escape        -- escape HTML relevant characters with their entities
   if \o~isA(.string) then o=o~string
   return o~changeStr("&","&amp;")~changeStr("<","&lt;")~changeStr(">","&gt;")

   ----------------------------------------------------------------------------


::routine dumpAccessibleMethods
  use strict arg jobj

  jclz=jobj~getClass    -- get object's class object

  clzModifier=bsf.loadClass("java.lang.reflect.Modifier")
  st=.stringTable~new               -- collects accessible method objects, collected in an array

  do counter level while jclz<>.nil
     dm=jclz~getDeclaredMethods     -- get all declared methods

     loop m over dm                 -- iterate over declared methods
        if isAccessible(m, level,clzModifier) then
        do
           mi=.methodInfo~new(jobj,m,level)  -- create instance
           name=mi~name             -- get name
           stArr=st[name]           -- get array object, if entry exists
           if stArr~isNil then
              st[name]=.array~of(mi)
           else
              stArr~append(mi)
        end
     end

     jclz=jclz~getSuperclass        -- now go up the hierarchy one level
  end

  say
  say "<p>The following table has four columns: <code>nr</code>, <code>name</code>,"
  say "<code>superclass level</code>, and method's <code>full name</code> at that level."
  say "If the method is a getter method (starts with 'get' or 'is' and has no parameters), then"
  say "it gets executed and the resulting value or exception gets shown in the next line.</p>"
  say
  say '<table class="center">'
  say .tab '<tr><th colspan="4">' "Accessible methods of" pp(jobj~getClass~toString) '</th></tr>'
  do counter i idx over st~allindexes~sortWith(.caselessComparator~new)
      stArr=st[idx]
      mi=stArr[1]    -- get first definition
      mb=.mutableBuffer~new

      mb~append(.tab, '<tr><td class="nr">', i, '</td> <td class="key">', mi~name, '</td>' )
      mb~append('<td class="nr">', mi~level, '</td>', '<td>', mi~fullDefinition, '</td>', '</tr>', .crlf)
      if mi~isGetter then
      do
          if mi~exception~isNil then
          do
             str="a getter, value:" pp(mi~getterValue~string)
             if wordpos(mi~name, "getAttributeNames getInitParameterNames getParameterNames")>0 then
             do
                mb2=.mutableBuffer~new
                call dumpEnumeration mb2, mi     -- show name->values in subtable
                if mb2<>"" then str=str mb2~string
             end
          end
          else
             str="a getter, exception:" pp(mi~exception~toString)

          mb~append(.tab, .tab, '<tr><td colspan="3"></td><td class="value">', str, "</td>", .crlf)
      end
      say mb~string

      do k=2 to stArr~items      -- show methods in upper level ?
         mb=.mutableBuffer~new
         mi=stArr[k]
         mb~append(.tab, .tab, '<tr><td colspan="2"></td>')
         mb~append('<td class="nr">', mi~level, '</td>', '<td>', mi~fullDefinition, '</td>', '</tr>', .crlf)
         if mi~isGetter then
         do
             if mi~exception~isNil then
                str="getter value:" pp(mi~getterValue~string)
             else
                str="getter exception:" pp(mi~exception~toString)

             mb~append(.tab, .tab, '<tr><td colspan="3"></td><td class="value">', str, "</td>", .crlf)
         end
         say mb~string
      end
      say
  end
  say "</table>"
  say

   /* dump the attributes/parameters:
      - getAttributeNames/getAttribute
      - getInitParameterNames/getInitParameter
      - getParameterNames/getParameter | getParameterMap
   */
::routine dumpEnumeration
    use arg mb, mi

    st=.stringTable~new
    getNamesMethod=mi~name
    accessor=getNamesMethod~left(getNamesMethod~pos("Names")-1)
    jobj=mi~jobj
    do n over jobj~send(getNamesMethod)
       val=jobj~send(accessor, n)
       st[n]=val        -- save value under name as index
    end
    if st~items=0 then return    -- nothing to do, empty enumeration

      -- create table with sorted attributes/parameters with their values
    psep=.rexxinfo~pathSeparator
    mb~append('<br>', .crlf, .tab3, "<table>")
    do counter i idx over st~allindexes~sortWith(.caselessComparator~new)
       mb~append(.crlf, .tab4)
       mb~append('<tr><td class="nr">', i, '</td> <td class="key">', idx, '</td>')
       val=st[idx]~string
       if idx~caselessEndsWith("path") then val=val~changestr(psep,psep"<br>")

       mb~append('<td class="value">', val, "</td></tr>")
    end
    mb~append(.crlf, .tab3, "</table>", .crlf)


::routine isAccessible              -- test whether public or protected if superclass level>1
  use arg jobj, level, clzModifier

  mods=jobj~getModifiers
  if clzModifier~isPublic(mods) then return .true
  if level>1 then return clzModifier~isProtected(mods)
  return .false         -- neither public, nor protected with level>1


::class methodInfo
::attribute    name           -- unqualified method name
::attribute    level          -- 1...base class, 2...superclass, ...
::attribute    fullDefinition -- fully qualified method name
::attribute    isGetter       -- a getter method
::attribute    jObj           -- the object which allows access to this method
::attribute    getterValue    -- the getter value
::attribute    exception      -- the exception caused by using the getter

::method string
 expose name level fullDefinition isGetter getterValue exception
 mb=.mutableBuffer~new

 mb~append("name=[", name, "]")
 if level>1 then mb~append("09"x)
 mb~append(",level=[",level,"]")
 mb~append(",fullDefinition=[", fullDefinition, "]")
 mb~append(.endofline, "09"x)

 if level>1 then mb~append("09"x)
 mb~append("isGetter=[", isGetter, "]")
 if isGetter then
 do
    if exception~isNil then
       mb~append(",getterValue=[", getterValue~string, "]")
    else
       mb~append(",exception=[", exception~string, "]")
    mb~append(.endofline)
 end
 return mb~string


::method init
  expose name level fullDefinition isGetter jObj getterValue exception
  use strict arg jobj, methObj, level
  name          =methObj~getName
  fullDefinition=methObj~toString
   -- assume a getter, if it starts with "get" or "is" and has no parameters

  isGetter=( name~startsWith("get") | name~startsWith("in") ) & methObj~getParameterTypes~size=0

  signal on syntax
  exception=.nil
  if isGetter then      -- fetch current value
     getterValue=methObj~invoke(jobj,.nil)
  return

syntax:
  co=condition('object')
  jexc=co~additional[2]    -- get at Java exception object
  do while \jexc~isNil
     exception=jexc        -- get origin Java exception
     jexc=jexc~getCause    -- get cause, if any
  end



/*
    ------------------------ Apache Version 2.0 license -------------------------
       Copyright 2020 Rony G. Flatscher

       Licensed under the Apache License, Version 2.0 (the "License");
       you may not use this file except in compliance with the License.
       You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing, software
       distributed under the License is distributed on an "AS IS" BASIS,
       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       See the License for the specific language governing permissions and
       limitations under the License.
    -----------------------------------------------------------------------------
    ------------------------ Common Public License 1.0 --------------------------
       Copyright 2020 Rony G. Flatscher

       This program and the accompanying materials are made available under the
       terms of the Common Public License v1.0 which accompanies this distribution.

       It may also be viewed at: http://www.opensource.org/licenses/cpl1.0.php
    -----------------------------------------------------------------------------
*/
