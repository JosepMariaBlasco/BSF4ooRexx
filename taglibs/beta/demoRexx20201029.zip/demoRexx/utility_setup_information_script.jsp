<%--
    ------------------------ Apache Version 2.0 license -------------------------
       Copyright 2020 Rony G. Flatscher

       Licensed under the Apache License, Version 2.0 (the "License");
       you may not use this file except in compliance with the License.
       You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing, software
       distributed under the License is distributed on an "AS IS" BASIS,
       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       See the License for the specific language governing permissions and
       limitations under the License.
    -----------------------------------------------------------------------------
    ------------------------ Common Public License 1.0 --------------------------
       Copyright 2020 Rony G. Flatscher

       This program and the accompanying materials are made available under the
       terms of the Common Public License v1.0 which accompanies this distribution.

       It may also be viewed at: http://www.opensource.org/licenses/cpl1.0.php
    -----------------------------------------------------------------------------
--%>

<%@ page session="false" pageEncoding="UTF-8" contentType="text/html; charset=UTF-8" %>
<%@ taglib uri="/WEB-INF/script-jsr223.tld" prefix="s" %>
<%-- note: - an external script can be of any size and complexity; this one
             will create all necessary HTML text
           - while developing set attribute "cacheSrc" to "false" such that changes
             in the program will be immediately reflected when refreshing the JSP page
--%>
<s:script type="rexx" src="code/createInformationPage.rex" />

