-- o=.bsf~new("mtest3.Class03B")             -- create Java object
o=.bsf~new("mtest3.Class03A")             -- create Java object
say "o:" o "o~myClassName:" o~myClassName -- get (static) field value

::requires BSF.CLS   -- direct interpreter to load Java bridge
